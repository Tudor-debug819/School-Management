export const environment = {
    production: false,
    firebaseConfig: {
        apiKey: "AIzaSyCqc-3cvxkjUtTRjFRjsEPD0dcGTZoRAbI",
        authDomain: "school-management-c3aa5.firebaseapp.com",
        projectId: "school-management-c3aa5",
        storageBucket: "school-management-c3aa5.firebasestorage.app",
        messagingSenderId: "531679268299",
        appId: "1:531679268299:web:c8275b63f809462a4b7a4e",
        measurementId: "G-BW2XSCZJ9H"
    }
}